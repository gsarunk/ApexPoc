---
title: First project
category: online projects
order: 40
---

## Repository Setup ##
* Create the repsitory on github, make sure it contains someting eg. a README file
* Start ZABAPGIT
* Clone the repository into abapGit

## Adding objects ##
* Navigate to the repository, click the "add" link
* It will ask for which object to add, select the object
* The object will be commited to the repository

## Modifying objects ##
After modifying a object, a "commit" link will show up in abapGit, click this to commit the changes to the remote repository.

## Modifying repository ##
If something is changed in the repository, a "pull" link will show up in abapGit. The changes must be pulled before new objects can be changed or added.