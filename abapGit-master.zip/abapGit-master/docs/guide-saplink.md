---
title: Migrating from SAPlink
category: other
order: 20
---

1: Install the slinkee/nuggets into the ABAP system using saplink

2: Use abapGit to export the objects as normal, see [http://docs.abapgit.org/guide-moving-package.html](http://docs.abapgit.org/guide-moving-package.html)
