---
title: Uninstall repository
category: online projects
order: 30
---

* Start ZABAPGIT
* Navigate to the repository

![](img/uninstall1.png)

* Click the "uninstall" link

![](img/uninstall2.png)

* It will now delete all objects in the package specified when installing the repository