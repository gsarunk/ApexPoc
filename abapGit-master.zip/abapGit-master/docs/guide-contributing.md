---
title: Contributing to a project
category: online projects
order: 60
---

* Fork the repository
* Clone the forked repository into the SAP system
* Do changes in SAP
* Commit the changes to the forked repository
* Submit pull request

The forked repository can be deleted after the pull request has been closed.