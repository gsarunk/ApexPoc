---
title: Export zip
category: offline projects
order: 20
---

Assuming the offline project has been created.

a: Download zip file

b: Unzip file to appropiate folder

c: Use your favorite git client to add/update the files in the repository

Do not rename the files or change folder locations of the files. This way an offline and online abapGit project will contain the same files, and both scenarios will work for all users.